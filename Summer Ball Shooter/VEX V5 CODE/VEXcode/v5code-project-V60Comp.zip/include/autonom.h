
//#include "turret.h"
#include "defines.h"
using namespace std;
using namespace G;
    
 
if(Color==Red) 
{ 
  switch (selection)
  {
    case 1:
    //#include "RedBlue1.h" 
    break;
    case 2:    
    #include "Red2.h" 
    break;
    case 3:
    #include "Red3.h" 
    break;
    case 4:
    #include "Red4.h" 
    break;
  }  
}
else 
{
switch (selection)
  {
    case 1:
    //#include "RedBlue1.h" 
    break;
    case 2:
    #include "Blue2.h" 
    break;
    case 3:
    #include "Blue3.h" 
    break;
    case 4:
    #include "Blue4.h" 
    break;
  } 


}


	while (1) { wait(100); }
    
