#include "defines.h"
using namespace std;
using namespace G;   
//pidTurn(-93,0.12, 0.03, .3, 4000);
//pidTurn(-57,0.1, 0.01, .3, 4000);
//pidTurn(57, 0.1, 0.01, .3, 4000);
//pidTurn(-90, 0.12, 0.01, .3, 4000);
pidTurn(93, 0.12, 0.01, .3, 4000);