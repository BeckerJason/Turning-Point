/*vex-vision-config:begin*/
#include "v5.h"
#include "v5_vcs.h"
vex::vision::signature REDFLAG = vex::vision::signature (1, 4853, 6987, 5920, 511, 929, 720, 3.8, 0);
vex::vision::signature BLUEFLAG = vex::vision::signature (2, -2907, -2539, -2722, 12097, 13811, 12954, 6.1, 0);
vex::vision::signature GREENFLAG = vex::vision::signature (3, -2923, -2143, -2532, -4293, -2659, -3476, 4.1, 0);
vex::vision::signature SIG_4 = vex::vision::signature (4, 0, 0, 0, 0, 0, 0, 3, 0);
vex::vision::signature SIG_5 = vex::vision::signature (5, 0, 0, 0, 0, 0, 0, 3, 0);
vex::vision::signature SIG_6 = vex::vision::signature (6, 0, 0, 0, 0, 0, 0, 3, 0);
vex::vision::signature BALL = vex::vision::signature (7, 0, 0, 0, 0, 0, 0, 3, 0);
vex::vision Vision = vex::vision (vex::PORT2, 75, REDFLAG, BLUEFLAG, GREENFLAG, SIG_4, SIG_5, SIG_6, BALL);
/*vex-vision-config:end*/