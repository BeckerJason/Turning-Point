#include "defines.h"
using namespace G;
using namespace std;
using namespace vex;

int RUNAUTO()
{
//PLACE AUTO CODE HERE


return 0;
}  