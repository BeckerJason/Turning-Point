#include "defines.h"
using namespace std;
using namespace G;

//while in tile
Tile(2,4000,0,brake);
wait(1000);
Tile(1.5,4000,1,brake);