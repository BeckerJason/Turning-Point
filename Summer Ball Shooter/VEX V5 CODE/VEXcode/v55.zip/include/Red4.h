#include "defines.h"
using namespace std;
using namespace G;  
